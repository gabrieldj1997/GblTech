<section class="w3l-footers-1">
    <div class="footer bg-secondary">
        <div class="container">
            <div class="footer-content">
                <div class="row">
                    <div class="col-lg-8 footer-left">
                        <p class="m-0">© Copyright 2021 Gbl Tech</p>
                    </div>
                    <div class="col-lg-4 footer-right text-lg-right text-center mt-lg-0 mt-3">
                        <ul class="social m-0 p-0">
                            <li><a href="https://www.linkedin.com/in/gabrieldj1997/" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                            <li><a href="https://github.com/gabrieldj1997" target="_blank"><span class="fa fa-github"></span></a></li>
                            <li><a href="https://api.whatsapp.com/send?phone=5561985863577" target="_blank"><span class="fa fa-whatsapp"></span></a></li>
                            <li><a href="https://t.me/Gabrieldj1997" target="_blank"><span class="fa fa-telegram"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\Projetos Pessoais\GblTech\resources\views///\layout/structure/footer.blade.php ENDPATH**/ ?>