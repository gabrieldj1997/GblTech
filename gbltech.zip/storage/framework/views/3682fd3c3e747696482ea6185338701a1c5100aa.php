<!doctype html>
<html lang="en">

<head>

    <?php echo $__env->make('layout.structure.head', ['title' => 'GBL Tech - Contato'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

    <?php if ($__env->exists('..\layout.structure.header', ["text" => " Contato", "position" => false])) echo $__env->make('..\layout.structure.header', ["text" => " Contato", "position" => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <section class="w3l-contacts-12 py-5">
        <div class="container py-md-3">
            <div class="contacts12-main">
                <div class="title-section">
                    <h3 class="main-title-w3 mb-md-5 mb-4">Want to get in touch? <br>Find me on
                        <a href="tel:+12-331-456-789" class="text-primary">phone</a>,
                        <a href="mailto:mymail@mail.com" class="text-primary">email</a>,
                        <a href="#twitter" class="text-primary">twitter</a>
                        or <a href="#linkedin" class="text-primary">linkedin</a>.
                    </h3>
                </div>
                <form action="https://sendmail.w3layouts.com/submitForm" method="post" class="">
                    <div class="main-input">
                        <input type="text" name="w3lName" placeholder="Enter your name" class="contact-input" required="" />
                        <input type="email" name="w3lSender" placeholder="Enter your mail" class="contact-input" required="" />
                        <input type="number" name="w3lPhone" placeholder="Your phone number" class="contact-input" required="" />
                        <textarea class="contact-textarea contact-input" name="w3lMessage" placeholder="Enter your message" required=""></textarea>
                    </div>
                    <div class="text-right">
                        <button class="btn-primary btn primary-btn-style">Send</button>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <section class="w3l-footers-1">
        <div class="footer bg-secondary">
            <div class="container">
                <div class="footer-content">
                    <div class="row">
                        <div class="col-lg-8 footer-left">
                            <p class="m-0">© Copyright 2020 Eccentric Portfolio. Design by <a href="https://w3layouts.com">W3layouts</a></p>
                        </div>
                        <div class="col-lg-4 footer-right text-lg-right text-center mt-lg-0 mt-3">
                            <ul class="social m-0 p-0">
                                <li><a href="#facebook"><span class="fa fa-facebook"></span></a></li>
                                <li><a href="#linkedin"><span class="fa fa-linkedin"></span></a></li>
                                <li><a href="#instagram"><span class="fa fa-instagram"></span></a></li>
                                <li><a href="#twitter"><span class="fa fa-twitter"></span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <button onclick="topFunction()" id="movetop" class="bg-primary" title="Go to top">
        <span class="fa fa-angle-up"></span>
    </button>
    <script>
        window.onscroll = function() {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("movetop").style.display = "block";
            } else {
                document.getElementById("movetop").style.display = "none";
            }
        }


        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>

    <script src="assets/js/jquery-3.3.1.min.js"></script>

    <script>
        $(function() {
            $('.navbar-toggler').click(function() {
                $('body').toggleClass('noscroll');
            })
        });
    </script>

    <script src="assets/js/bootstrap.min.js"></script>


</body>

</html><?php /**PATH D:\Projetos Pessoais\GblTech\resources\views/pages/contact.blade.php ENDPATH**/ ?>