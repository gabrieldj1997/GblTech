<div class="w3l-banner-slider">
    <div class="wrapper-container">

        <main class="sliders-container">

            <ul class="pagination">
                <li class="pagination__item"><a class="pagination__button"></a></li>
                <li class="pagination__item"><a class="pagination__button"></a></li>
                <li class="pagination__item"><a class="pagination__button"></a></li>
                <li class="pagination__item"><a class="pagination__button"></a></li>
            </ul>
            <div class="social">
                <a class="" href="#linkedin"><span class="fa fa-linkedin"></span></a>
                <a class="" href="#github"><span class="fa fa-github"></span></a>
                <a class="" href="#whatsapp"><span class="fa fa-whatsapp"></span></a>
            </div>
        </main>
    </div>
</div><?php /**PATH D:\Projetos Pessoais\GblTech\resources\views///\layout/section/slider.blade.php ENDPATH**/ ?>