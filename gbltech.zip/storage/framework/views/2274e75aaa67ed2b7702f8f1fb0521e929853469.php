<section class="w3l-blog py-5 bg-light">
    <div class="container py-lg-5 py-md-3">
        <div class="row">
            <div class="col-lg-5">
                <h3>Sed volutpat eget dui ut tempus init.</h3>
                <h5 class="mt-3">Fusce fringilla tincidunt laoreet volutpat cras varius sit </h5>
                <p class="mt-4"> Sed in metus libero. Sed volutpat eget dui ut tempus. Fusce fringilla tincidunt laoreet
                    Morbi ac metus vitae diam scelerisque malesuada eget eu mauris. Cras varius lorem ac velit pharetra,
                    non scelerisque mi vulputate. Phasellus bibendum suscipit nunc, non semper erat iaculis in. Nulla
                    volutpat porttitor magna vel euismod. Aenean sit amet diam nec sem
                    amet metus.</p>
            </div>
            <div class="col-lg-7 mt-lg-0 mt-4">
                <div class="img-block">
                    <a href="#single">
                        <img src="assets/images/g1.jpg" class="img-fluid" alt="image" />
                        <span>Modern Ecommerce Website Design</span>
                    </a>
                </div>
                <div class="img-block mt-3">
                    <a href="#single"> <img src="assets/images/g2.jpg" class="img-fluid" alt="image" />
                        <span>Personalized Portfolio work</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\Projetos Pessoais\GblTech\resources\views///\layout/section/services.blade.php ENDPATH**/ ?>