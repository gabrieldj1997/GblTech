<div class="w3l-content-photo-5 py-5">
    <div class="content-main py-lg-5 py-md-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 content-left">
                    <h3>Eu sou um desenvolvedor, e quero trazer facilidade e soluções que vão tornar sua empresa inovadora</h3>
                    <p class="mb-0">Olá meu nom é Gabriel e quero apresentar soluções que irão transformar sua empresa e o seu jeito de trbalhar.
                        Soluções automatizadas para poupar seu tempo e integra-lo ao mundo digital, podendo assim captar mais clientes e também impressiona-los.
                        Em meio a pandemia que estamos vivendo o mundo digital nunca esteve tão presente, empresas que não pensa mais pelo lado digital estão
                        ficando para trás, para evitar isso temos que pensar em soluções web e mobile, para que você trabalhe com a maior perfomance e seja visto
                        por todos!
                    </p>
                    <a href="#linkedin" class="primary-btn-style btn-primary btn mt-lg-5 mt-4">LinkedIn</a>
                </div>
                <div class="col-lg-4 content-photo mt-lg-0 mt-sm-5 mb-md-0 mb-4">
                    <a href="#img"><img src="assets/images/myimage.jpg" class="img-fluid" alt="content-photo"></a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Projetos Pessoais\GblTech\resources\views///\layout/section/about-me.blade.php ENDPATH**/ ?>