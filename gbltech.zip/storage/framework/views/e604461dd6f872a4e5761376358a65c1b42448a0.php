<section class="w3l-quote-main">
    <div class="quote py-5">
        <div class="container py-lg-5">
            <div class="row">
                <div class="col-lg-9">
                    <h4>" I've worked with some X company for several years and that is the best company in the Market.
                        Mauris elementum tortor a nisl
                        aliquet fringilla. Donec et risus augue. Proin sit amet maximus dui Vivamus lacinia nisi tempor
                        ligula sagittis vehicula."</h4>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-3 text-lg-center tablet-grid">
                    <img src="assets/images/client2.jpg" alt="" class="img-fluid" />
                    <div>
                        <h6 class="mb-0 mt-lg-3">Johnson smith</h6>
                        <h5 class="mt-1">- UI/UX Designer </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\Projetos Pessoais\GblTech\resources\views///\layout/section/clients.blade.php ENDPATH**/ ?>