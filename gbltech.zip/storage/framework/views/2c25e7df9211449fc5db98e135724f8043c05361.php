<section class="w3l-blog py-5">
    <div class="container py-lg-5">
        <div class="row">
            <div class="col-lg-3 col-6 pr-md-3 pr-2">
                <div class="img-block">
                    <a href="#img">
                        <img src="assets/images/iphone1.png" class="img-fluid" alt="image" />
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-6 pl-md-3 pl-2">
                <div class="img-block">
                    <a href="#img">
                        <img src="assets/images/iphone2.png" class="img-fluid" alt="image" />
                    </a>
                </div>
            </div>
            <div class="col-lg-6 mt-lg-0 mt-md-5 mt-4">
                <h3>Sed volutpat eget dui ut tempus init bibendum nunc.</h3>
                <h5 class="mt-3">Fusce fringilla tincidunt laoreet volutpat cras varius sit suscipit.</h5>
                <p class="mt-4 mb-0"> Sed in metus libero. Sed volutpat eget dui ut tempus. Fusce fringilla tincidunt laoreet
                    Morbi ac metus vitae diam scelerisque malesuada eget eu mauris. Cras varius lorem ac velit pharetra,
                    non scelerisque mi vulputate. Phasellus bibendum suscipit nunc, non semper erat iaculis in. Nulla
                    volutpat porttitor magna vel euismod. Aenean sit amet diam nec sem
                    amet metus.</p>
                <a href="#blog.html" class="primary-btn-style btn-primary btn mt-lg-5 mt-4">View my project</a>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\Projetos Pessoais\GblTech\resources\views///\layout/section/mobile.blade.php ENDPATH**/ ?>