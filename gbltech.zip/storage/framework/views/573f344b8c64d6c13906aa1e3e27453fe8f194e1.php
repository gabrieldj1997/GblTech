<section class="w3l-grid-quote py-5">
    <div class="container py-lg-3">
        <h6>I'am available for freelance projects.</h6>
        <h3>Let's work together indeed!</h3>
        <a href="/contact" class="secondary-btn-style btn-secondary btn">Get quotes</a>
        <a href="/contact" class="btn btn-style text-primary ml-2">Hire me</a>
    </div>
</section><?php /**PATH D:\Projetos Pessoais\GblTech\resources\views///\layout/section/cadaster.blade.php ENDPATH**/ ?>